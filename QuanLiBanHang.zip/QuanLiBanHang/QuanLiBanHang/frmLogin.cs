﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLiBanHang
{
    public partial class frmLogin : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataAdapter data;
        public frmLogin()
        {
            InitializeComponent();
        }
        void connect()
        {
            String sqlcon = "initial catalog = QuanLiBanHang; data source = DESKTOP-HK5LL88; integrated security = true";
            cn = new SqlConnection(sqlcon);
            cn.Open();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            connect();
        }
        String checkAccount(String username, String password)
        {
            String s = "select * from Account where username = '" + username + "' and passwords = '" + password + "'";
            data = new SqlDataAdapter(s, cn);
            DataTable tb = new DataTable();
            data.Fill(tb);
            if (tb.Rows.Count > 0)
                return tb.Rows[0][0].ToString();
            return "";//ko co tk

        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            Program.username = checkAccount(txtUsername.Text, txtPassword.Text);
            if (Program.username == "nhavien1")
            {
                frmE f = new frmE();
                f.Show();
                this.Hide();

            }
            else
            {
                frmP p = new frmP();
                p.Show();
                this.Hide();

            }
        }
    }
}
